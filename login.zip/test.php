<?php
require_once 'core/init.php';
var_dump(Session::get('recommand_cars'));
?>